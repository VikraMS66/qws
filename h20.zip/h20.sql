-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 11:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `h20`
--

-- --------------------------------------------------------

--
-- Table structure for table `addressbook`
--

CREATE TABLE `addressbook` (
  `id` int(20) NOT NULL,
  `custid` bigint(10) NOT NULL,
  `tagName` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mNumber` bigint(10) NOT NULL,
  `pincode` int(6) NOT NULL,
  `gCode` varchar(50) DEFAULT NULL,
  `address` varchar(500) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addressbook`
--

INSERT INTO `addressbook` (`id`, `custid`, `tagName`, `name`, `mNumber`, `pincode`, `gCode`, `address`, `date`) VALUES
(47, 9663494174, 'Home', 'Shaik Saad', 8884899801, 585401, 'VG+45G', ' Chidri Bidar', '2022-07-18 20:08:30');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `setid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `number`, `password`, `setid`) VALUES
(1, 'Vikram', 9663494174, 'vikram', 1);

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE `agent` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `role` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `selectedid` bigint(10) DEFAULT NULL,
  `orderid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`id`, `name`, `number`, `role`, `email`, `password`, `selectedid`, `orderid`) VALUES
(1, 'Vikram Singh', 9663494174, 'Associate', 'vikrams@gmail.com', 'vikram', 9972145655, 51),
(4, 'Shaik Saad', 9972145655, 'Blocked', 'saad@gmail.com', 'vikram', 9972145655, 7),
(5, 'Saad ', 8884899801, 'Manager', 'saad@gmail.com', 'vikram', 9972145655, 6);

-- --------------------------------------------------------

--
-- Table structure for table `bug`
--

CREATE TABLE `bug` (
  `id` int(10) NOT NULL,
  `reportedby` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `reporterNumber` bigint(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Registered'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bug`
--

INSERT INTO `bug` (`id`, `reportedby`, `name`, `number`, `email`, `message`, `date`, `reporterNumber`, `status`) VALUES
(6, 'customer', 'Vikram Singh', 9663494174, 'vikram@gmail.com', 'Something!', '2022-07-11 00:00:00', 9663494174, 'Closed'),
(7, 'customer', 'Saad', 8050626051, 'saad@gamil.com', 'Something!', '2022-07-11 00:00:00', 9663494174, 'Registered'),
(8, 'agent', 'Vikram', 9663494174, 'vikram@gmail.com', 'Something!', '2022-07-11 00:00:00', 9663494174, 'Registered'),
(9, 'seller', 'Vikram S', 9972145655, 'saad@gmail.com', 'Something Not Working.', '2022-07-11 00:00:00', 9663494174, 'Registered'),
(11, 'customer', 'Shaik Saad', 9663494174, 'saad@gmail.com', 'order button is not working ', '2022-07-18 21:57:30', 9663494174, 'In Process');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(10) NOT NULL,
  `orderid` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `issue` varchar(500) NOT NULL,
  `message` varchar(500) NOT NULL DEFAULT 'In Process',
  `complaintby` varchar(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `agentNumber` bigint(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Registered'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`id`, `orderid`, `name`, `number`, `issue`, `message`, `complaintby`, `date`, `agentNumber`, `status`) VALUES
(6, 49, 'Shaik Saad', 9663494174, 'Order was not delivered', 'Closed ', 'customer', '2022-07-18 20:40:13', 9663494174, 'Registered'),
(7, 51, 'Shaik Saad', 9663494174, 'order not delivered but showing deliverd ', 'seller blocked', 'customer', '2022-07-18 21:42:17', 9663494174, 'Resolved'),
(8, 51, 'Shaik Saad', 9663494174, 'Order Not delivered but showing delivered.', 'Seller Blocked', 'customer', '2022-07-19 01:18:48', 9663494174, 'Resolved');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `userid` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mNumber` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `addressId` int(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`userid`, `name`, `mNumber`, `email`, `password`, `addressId`, `status`, `date`) VALUES
(25, 'Shaik Saad', 9663494174, 'saad@gmail.com', 'vikram', 47, NULL, '2022-07-18 20:07:56');

-- --------------------------------------------------------

--
-- Table structure for table `fillup`
--

CREATE TABLE `fillup` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  `pincode` int(6) NOT NULL,
  `gCode` varchar(50) DEFAULT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fillup`
--

INSERT INTO `fillup` (`id`, `name`, `number`, `status`, `pincode`, `gCode`, `address`) VALUES
(1, 'Vikram', 9900278155, 'Active', 585401, 'VG+34J santosh colony', 'Bidar Chidri'),
(2, 'Vivek Resorces', 8884563542, 'Active', 585401, 'Not Found', 'Bidar Old City'),
(3, 'Rajesh Water', 9663494176, 'Active', 585401, 'VG+G45', 'Gumpa Road Bidar '),
(6, 'Rajesh', 8050626051, 'Active', 585401, 'VG+76J Shapure, Karnataka ', 'Bidar '),
(7, 'Vikas', 9632145870, 'Active', 585401, '', 'Nawadgeri Bidar');

-- --------------------------------------------------------

--
-- Table structure for table `helpcart`
--

CREATE TABLE `helpcart` (
  `supplieid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `onboardsupply`
--

CREATE TABLE `onboardsupply` (
  `id` int(20) NOT NULL,
  `sellerid` bigint(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` bigint(10) NOT NULL,
  `status` varchar(20) DEFAULT 'Deactive',
  `pincode` int(6) NOT NULL,
  `capacity` int(10) NOT NULL,
  `multiOrderCount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `onboardsupply`
--

INSERT INTO `onboardsupply` (`id`, `sellerid`, `name`, `number`, `status`, `pincode`, `capacity`, `multiOrderCount`) VALUES
(10, 9972145655, 'Nazrul', 9972145655, 'Deactive', 585401, 5000, 1),
(11, 8884899801, 'imran', 8884899801, 'Active', 585403, 1000, 1),
(12, 8884899801, 'imran ', 8884899801, 'Active', 585403, 5000, 1),
(13, 9972145655, 'saad', 9972145655, 'Deactive', 585401, 1000, 2),
(14, 9972145655, 'saad', 8884899801, 'Deactive', 585401, 10000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(20) NOT NULL,
  `custid` bigint(10) NOT NULL,
  `supid` bigint(10) NOT NULL,
  `supplyid` int(10) NOT NULL,
  `product` varchar(20) NOT NULL,
  `custName` varchar(20) NOT NULL,
  `custNumber` bigint(10) NOT NULL,
  `address` varchar(500) NOT NULL,
  `pincode` int(6) NOT NULL,
  `gCode` varchar(50) DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `supName` varchar(20) NOT NULL,
  `supNumber` bigint(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `etd` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Placed',
  `rating` int(10) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `custid`, `supid`, `supplyid`, `product`, `custName`, `custNumber`, `address`, `pincode`, `gCode`, `amount`, `supName`, `supNumber`, `date`, `etd`, `status`, `rating`) VALUES
(49, 9663494174, 9972145655, 10, '1000', 'Shaik Saad', 8884899801, ' Chidri Bidar', 585401, 'VG+45G', 308, 'Nazrul', 9972145655, '2022-07-18 15:06:01', '10:35 PM', 'Delivered', 5),
(50, 9663494174, 9972145655, 10, '1000', 'vikram singh', 9663494174, 'Bidar\nKarnataka\n585403', 585401, '', 308, 'Nazrul', 9972145655, '2022-07-18 15:28:10', '10:57 PM', 'Cancelled', 0),
(51, 9663494174, 9972145655, 10, '5000', 'Shaik Saad', 8884899801, ' Chidri Bidar', 585401, 'VG+45G', 1130, 'Nazrul', 9972145655, '2022-07-18 16:04:13', '12:34 PM', 'Cancelled', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sellerupdate`
--

CREATE TABLE `sellerupdate` (
  `id` int(10) NOT NULL,
  `sNumber` bigint(10) NOT NULL,
  `agentNumber` bigint(10) NOT NULL,
  `cName` varchar(20) DEFAULT NULL,
  `gst` varchar(20) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sellerupdate`
--

INSERT INTO `sellerupdate` (`id`, `sNumber`, `agentNumber`, `cName`, `gst`, `comment`, `date`) VALUES
(7, 9972145655, 9663494174, 'WATER RESOURCES', 'FSD4SF4SDFRT', 'Update GST Number', '2022-07-19 01:20:29');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supid` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mNumber` bigint(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `companyName` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Requested',
  `statusMsg` varchar(100) DEFAULT 'In Process',
  `pincode` int(6) NOT NULL,
  `gCode` varchar(50) DEFAULT NULL,
  `address` varchar(500) NOT NULL,
  `gstNumber` varchar(20) DEFAULT NULL,
  `selectedSupplier` int(10) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supid`, `name`, `email`, `mNumber`, `password`, `companyName`, `status`, `statusMsg`, `pincode`, `gCode`, `address`, `gstNumber`, `selectedSupplier`, `date`) VALUES
(1, 'Vikram S', 'saad@gmail.com', 9972145655, 'vikram', 'WATER RESOURCES', 'In Process', 'Verification in process\n', 585403, 'VG+G45', 'old City Bidar India', 'FSD4SF4SDFE', 10, '2022-07-11 19:44:40'),
(3, 'Vikram Singh', 'vikram@hotmail.com', 9663494174, 'vikram', 'Water Reserve', 'Approved', 'Updated', 585401, 'VG+G45F', 'Chowbra Bidar', 'ING7HUIH3', 8, '2022-07-11 19:44:40'),
(4, 'imran', 'imran@gmail.com', 8884899801, 'imran123', 'water supply', 'Approved', 'updated', 585403, '', 'Bidar', 'XTD21165', 12, '2022-07-18 21:25:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addressbook`
--
ALTER TABLE `addressbook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addressbook_ibfk_1` (`custid`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `number` (`number`);

--
-- Indexes for table `bug`
--
ALTER TABLE `bug`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reporterNumber` (`reporterNumber`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `mNumber` (`mNumber`),
  ADD KEY `customer_ibfk_1` (`addressId`);

--
-- Indexes for table `fillup`
--
ALTER TABLE `fillup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `number` (`number`);

--
-- Indexes for table `onboardsupply`
--
ALTER TABLE `onboardsupply`
  ADD PRIMARY KEY (`id`),
  ADD KEY `onboardsupply_ibfk_1` (`sellerid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_ibfk_1` (`custid`),
  ADD KEY `orders_ibfk_2` (`supid`),
  ADD KEY `supplyid` (`supplyid`);

--
-- Indexes for table `sellerupdate`
--
ALTER TABLE `sellerupdate`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sNumber` (`sNumber`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supid`),
  ADD UNIQUE KEY `mNumber` (`mNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addressbook`
--
ALTER TABLE `addressbook`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `agent`
--
ALTER TABLE `agent`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bug`
--
ALTER TABLE `bug`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `fillup`
--
ALTER TABLE `fillup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `onboardsupply`
--
ALTER TABLE `onboardsupply`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `sellerupdate`
--
ALTER TABLE `sellerupdate`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addressbook`
--
ALTER TABLE `addressbook`
  ADD CONSTRAINT `addressbook_ibfk_1` FOREIGN KEY (`custid`) REFERENCES `customer` (`mNumber`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bug`
--
ALTER TABLE `bug`
  ADD CONSTRAINT `bug_ibfk_1` FOREIGN KEY (`reporterNumber`) REFERENCES `agent` (`number`) ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`addressId`) REFERENCES `addressbook` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`supid`) REFERENCES `supplier` (`mNumber`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
